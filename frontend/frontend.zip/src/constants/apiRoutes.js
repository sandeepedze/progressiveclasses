export const API_ROUTES = {
    AUTH: {
        LOGIN: '/auth/login',
        REFRESH: '/auth/refresh',
        LOGOUT: '/auth/logout',
        ME: '/auth/me',
    },
    SUPER_ADMIN: {
        CREATE_SCHOOL: '/superadmin/schools/create',
        ASSIGN_PLAN: '/superadmin/schools/assign-plan',
        DASHBOARD_STATS: '/superadmin/dashboard/stats',
        CREATE_PLAN: '/superadmin/plans/create',
        MAP_MODULES: '/superadmin/plans/map-modules',
    },
    SCHOOL: {
        LIST: '/schools',
        DETAILS: (id) => `/schools/${id}`,
    },
    SUBSCRIPTION: {
        PLANS: '/plans',
    }
    ,
    USER: {
        UPLOAD_AVATAR: '/users/upload-avatar'
    }
};

export const API_CONFIG = {
    BASE_URL: 'http://192.168.29.138:5000/api', // Updated Auto-IP
    TIMEOUT: 15000,
};
