import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import * as SecureStore from 'expo-secure-store';
import { authService } from '../../services';

// Simulate API call for now, replace with real API
export const loginUser = createAsyncThunk(
    'auth/loginUser',
    async (credentials, { rejectWithValue }) => {
        try {
            // In real app: const response = await api.post('/auth/login', credentials);
            // For demo, we mock based on email
            // credentials.email / password

            let role = 'teacher';
            if (credentials.email.includes('super')) role = 'super_admin';
            else if (credentials.email.includes('admin')) role = 'school_admin';

            const mockResponse = {
                token: 'mock-jwt-token-123',
                user: {
                    id: 1,
                    email: credentials.email,
                    name: 'User ' + role,
                    role: role,
                }
            };

            // Store token
            await SecureStore.setItemAsync('userToken', mockResponse.token);
            await SecureStore.setItemAsync('userData', JSON.stringify(mockResponse.user));

            return mockResponse;
        } catch (error) {
            return rejectWithValue(error.response?.data || 'Login failed');
        }
    }
);

export const restoreToken = createAsyncThunk(
    'auth/restoreToken',
    async () => {
        const token = await SecureStore.getItemAsync('userToken');
        const user = await SecureStore.getItemAsync('userData');
        if (token && user) {
            return { token, user: JSON.parse(user) };
        }
        throw new Error('No token');
    }
);

export const logoutUser = createAsyncThunk(
    'auth/logout',
    async () => {
        try {
            await authService.logout();
        } catch (e) {
            // Ignore API error during logout
        }
        await SecureStore.deleteItemAsync('userToken');
        await SecureStore.deleteItemAsync('userData');
    }
);

const authSlice = createSlice({
    name: 'auth',
    initialState: {
        user: null,
        token: null,
        isAuthenticated: false,
        isLoading: true,
        error: null,
    },
    reducers: {
        setProfileImage: (state, action) => {
            if (state.user) {
                state.user.profile_image = action.payload;
            }
        }
    },
    extraReducers: (builder) => {
        builder
            .addCase(loginUser.pending, (state) => {
                state.isLoading = true;
                state.error = null;
            })
            .addCase(loginUser.fulfilled, (state, action) => {
                state.isLoading = false;
                state.isAuthenticated = true;
                state.user = action.payload.user;
                state.token = action.payload.token;
            })
            .addCase(loginUser.rejected, (state, action) => {
                state.isLoading = false;
                state.error = action.payload;
            })
            .addCase(restoreToken.fulfilled, (state, action) => {
                state.isAuthenticated = true;
                state.user = action.payload.user;
                state.token = action.payload.token;
                state.isLoading = false;
            })
            .addCase(restoreToken.rejected, (state) => {
                state.isLoading = false;
                state.isAuthenticated = false;
            })
            .addCase(logoutUser.fulfilled, (state) => {
                state.user = null;
                state.token = null;
                state.isAuthenticated = false;
            });
    },
});

export const { setProfileImage } = authSlice.actions;
export default authSlice.reducer;
