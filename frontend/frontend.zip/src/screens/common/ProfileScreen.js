import React from 'react';
import { View, ScrollView, Text } from 'react-native';
import { useSelector, useDispatch } from 'react-redux';
import { useNavigation } from '@react-navigation/native';
import { SafeAreaView } from 'react-native-safe-area-context';
import AppHeader from '../../components/layout/AppHeader';
import { logoutUser } from '../../features/auth/authSlice';
import ProfileHeaderCard from '../../components/common/ProfileHeaderCard';
import SettingsMenuItem from '../../components/common/SettingsMenuItem';
import LogoutButton from '../../components/common/LogoutButton';
import { User, Shield, School, Calendar, Mail, Phone } from 'lucide-react-native';
import * as ImagePicker from 'expo-image-picker';
import { userService } from '../../services';
import { setProfileImage } from '../../features/auth/authSlice';
import * as SecureStore from 'expo-secure-store';
import AppButton from '../../components/ui/AppButton';

const ProfileScreen = () => {
    const dispatch = useDispatch();
    const navigation = useNavigation();
    const { user } = useSelector(state => state.auth);

    const handleLogout = async () => {
        try {
            await dispatch(logoutUser()).unwrap();
            // Navigation reset is handled by AppNavigator listening to isAuthenticated state
        } catch (error) {
            console.error('Logout failed:', error);
        }
    };

    const handleUploadAvatar = async () => {
        try {
            const permission = await ImagePicker.requestMediaLibraryPermissionsAsync();
            if (permission.status !== 'granted') {
                return;
            }
            const result = await ImagePicker.launchImageLibraryAsync({
                mediaTypes: ImagePicker.MediaTypeOptions.Images,
                allowsEditing: true,
                aspect: [1, 1],
                quality: 0.8,
            });
            if (result?.assets?.length) {
                const asset = result.assets[0];
                const formData = new FormData();
                formData.append('avatar', {
                    uri: asset.uri,
                    name: 'avatar.jpg',
                    type: 'image/jpeg',
                });
                const res = await userService.uploadAvatar(formData);
                if (res?.success && res?.url) {
                    dispatch(setProfileImage(res.url));
                    const updatedUser = { ...user, profile_image: res.url };
                    await SecureStore.setItemAsync('userData', JSON.stringify(updatedUser));
                }
            }
        } catch (e) {
            console.log('Avatar upload error:', e);
        }
    };

    return (
        <SafeAreaView className="flex-1 bg-slate-50" edges={['top']}>
            <AppHeader title="Profile" showBack={false} />

            <ScrollView className="flex-1" contentContainerStyle={{ padding: 16, paddingBottom: 120 }}>
                <ProfileHeaderCard user={user} />

                <View className="bg-white rounded-2xl shadow-sm border border-slate-100 overflow-hidden mb-6">
                    <View className="px-4 py-3 bg-slate-50 border-b border-slate-100">
                        <Text className="font-bold text-slate-500 uppercase text-xs tracking-wider">
                            Personal Information
                        </Text>
                    </View>

                    <SettingsMenuItem
                        icon={<Mail size={20} color="#64748B" />}
                        label="Email"
                        value={user?.email}
                        showChevron={false}
                        onPress={() => { }}
                    />
                    <SettingsMenuItem
                        icon={<User size={20} color="#64748B" />}
                        label="Name"
                        value={user?.name}
                        showChevron={false}
                        onPress={() => { }}
                    />
                    <SettingsMenuItem
                        icon={<Shield size={20} color="#64748B" />}
                        label="Role"
                        value={user?.role}
                        showChevron={false}
                        onPress={() => { }}
                    />
                    <SettingsMenuItem
                        icon={<Calendar size={20} color="#64748B" />}
                        label="Joined"
                        value={new Date().toLocaleDateString()} // Placeholder
                        showChevron={false}
                        onPress={() => { }}
                    />
                </View>

                <AppButton title="Upload Avatar" variant="outline" onPress={handleUploadAvatar} className="mt-2" />

                {user?.school_id && (
                    <View className="bg-white rounded-2xl shadow-sm border border-slate-100 overflow-hidden mb-6">
                        <View className="px-4 py-3 bg-slate-50 border-b border-slate-100">
                            <Text className="font-bold text-slate-500 uppercase text-xs tracking-wider">
                                School Information
                            </Text>
                        </View>
                        <SettingsMenuItem
                            icon={<School size={20} color="#64748B" />}
                            label="School ID"
                            value={`#${user.school_id}`}
                            showChevron={false}
                            onPress={() => { }}
                        />
                    </View>
                )}

                <LogoutButton onLogout={handleLogout} />

                <View className="h-10" />
            </ScrollView>
        </SafeAreaView>
    );
};

export default ProfileScreen;