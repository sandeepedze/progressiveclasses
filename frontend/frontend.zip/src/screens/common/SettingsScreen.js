import React, { useState } from 'react';
import { View, ScrollView, Text, Switch, TouchableOpacity } from 'react-native';
import { useDispatch, useSelector } from 'react-redux';
import { useNavigation } from '@react-navigation/native';
import { SafeAreaView } from 'react-native-safe-area-context';
import {
    User, Shield, Moon, Bell, HelpCircle,
    FileText, LogOut, ChevronRight, Lock
} from 'lucide-react-native';

import AppHeader from '../../components/layout/AppHeader';
import SettingsMenuItem from '../../components/common/SettingsMenuItem'; // Using the component we know exists
import LogoutButton from '../../components/common/LogoutButton';
import { toggleTheme } from '../../features/ui/uiSlice';
import { logoutUser } from '../../features/auth/authSlice';
import * as SecureStore from 'expo-secure-store';
import { useToast } from '../../context/ToastContext';

const SettingsSection = ({ title, children }) => (
    <View className="mb-6 bg-white border-y border-slate-100 sm:rounded-2xl sm:border sm:shadow-sm sm:overflow-hidden">
        {title && (
            <View className="px-5 py-3 bg-slate-50 border-b border-slate-100">
                <Text className="text-xs font-bold text-slate-500 uppercase tracking-wider">
                    {title}
                </Text>
            </View>
        )}
        {children}
    </View>
);

const SettingsScreen = () => {
    const dispatch = useDispatch();
    const navigation = useNavigation();
    const theme = useSelector(state => state.ui.theme);
    const { showToast } = useToast();

    // Local state for notifications (mock)
    const [notificationsEnabled, setNotificationsEnabled] = useState(true);

    const handleLogout = async () => {
        try {
            await SecureStore.deleteItemAsync('userToken');
            await SecureStore.deleteItemAsync('userData');
            await dispatch(logoutUser()).unwrap();
            showToast('Logged out successfully', 'success');
        } catch (error) {
            console.error('Logout failed:', error);
            showToast('Logout failed', 'error');
        }
    };

    const handleThemeToggle = () => {
        dispatch(toggleTheme());
        SecureStore.setItemAsync('appTheme', theme === 'light' ? 'dark' : 'light');
    };

    return (
        <SafeAreaView className="flex-1 bg-slate-50" edges={['top']}>
            <AppHeader title="Settings" showBack={false} />

            <ScrollView className="flex-1" contentContainerStyle={{ paddingVertical: 20 }}>

                {/* Account Section */}
                <SettingsSection title="Account">
                    <SettingsMenuItem
                        icon={<User size={20} color="#64748B" />}
                        label="Personal Information"
                        onPress={() => navigation.navigate('Profile')}
                    />
                    <SettingsMenuItem
                        icon={<Shield size={20} color="#64748B" />}
                        label="Security & Password"
                        onPress={() => { /* Navigate to SecurityScreen */ }}
                        value="2FA Off"
                    />
                </SettingsSection>

                {/* Preferences Section */}
                <SettingsSection title="Preferences">
                    <View className="flex-row items-center justify-between p-4 bg-white border-b border-slate-50">
                        <View className="flex-row items-center flex-1">
                            <View className="w-10 h-10 rounded-full items-center justify-center mr-4 bg-indigo-50">
                                <Moon size={20} color="#4F46E5" />
                            </View>
                            <Text className="text-base font-medium text-slate-700">Dark Mode</Text>
                        </View>
                        <Switch
                            value={theme === 'dark'}
                            onValueChange={handleThemeToggle}
                            trackColor={{ false: '#CBD5E1', true: '#818CF8' }}
                            thumbColor={theme === 'dark' ? '#4F46E5' : '#F8FAFC'}
                        />
                    </View>

                    <View className="flex-row items-center justify-between p-4 bg-white">
                        <View className="flex-row items-center flex-1">
                            <View className="w-10 h-10 rounded-full items-center justify-center mr-4 bg-amber-50">
                                <Bell size={20} color="#D97706" />
                            </View>
                            <Text className="text-base font-medium text-slate-700">Notifications</Text>
                        </View>
                        <Switch
                            value={notificationsEnabled}
                            onValueChange={setNotificationsEnabled}
                            trackColor={{ false: '#CBD5E1', true: '#818CF8' }}
                            thumbColor={notificationsEnabled ? '#4F46E5' : '#F8FAFC'}
                        />
                    </View>
                </SettingsSection>

                {/* Support Section */}
                <SettingsSection title="Support">
                    <SettingsMenuItem
                        icon={<HelpCircle size={20} color="#64748B" />}
                        label="Help & Support"
                        onPress={() => { }}
                    />
                    <SettingsMenuItem
                        icon={<FileText size={20} color="#64748B" />}
                        label="Terms & Privacy"
                        onPress={() => { }}
                    />
                </SettingsSection>

                <View className="px-4">
                    <LogoutButton onLogout={handleLogout} />
                    <Text className="text-center text-slate-400 text-xs mt-6">
                        Version 1.0.0 (Build 102)
                    </Text>
                </View>

                <View className="h-20" />
            </ScrollView>
        </SafeAreaView>
    );
};

export default SettingsScreen;
