import React, { useState } from 'react';
import { View, Text, ScrollView } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import AppInput from '../../components/ui/AppInput';
import AppButton from '../../components/ui/AppButton';
import AppCard from '../../components/ui/AppCard';
import { User, Mail, Lock, Phone, MapPin, Building } from 'lucide-react-native';
import { useApiMutation } from '../../hooks/useApiMutation';
import { schoolService } from '../../services';
import { ScreenWrapper } from '../../components/ui/system/SystemComponents';
import { AppFormError } from '../../components/ui/forms/AppFormError';

const CreateSchoolScreen = ({ navigation }) => {
    const [form, setForm] = useState({
        school_name: '',
        school_code: '',
        email: '',
        phone: '',
        address: '',
        admin_name: '',
        admin_email: '',
        admin_password: ''
    });

    const { mutate, isLoading, error } = useApiMutation(schoolService.createSchool, {
        successMessage: 'School registered successfully!',
        onSuccess: (data) => {
            // Add slight delay before going back so user sees the toast
            setTimeout(() => navigation.goBack(), 1000);
        }
    });

    const handleChange = (key, value) => {
        setForm({ ...form, [key]: value });
    };

    const handleSubmit = () => {
        mutate(form);
    };

    return (
        <ScreenWrapper loading={isLoading}>
            <SafeAreaView className="flex-1">
                <View className="px-5 py-3 border-b border-slate-200 bg-white">
                    <Text className="text-xl font-bold text-slate-800">Onboard New School</Text>
                </View>

                <ScrollView className="flex-1 p-5">
                    <AppFormError error={error} />

                    <Text className="text-lg font-bold text-slate-800 mb-4">School Details</Text>
                    <AppCard>
                        <AppInput
                            label="School Name"
                            placeholder="e.g. Springfield High"
                            value={form.school_name}
                            onChangeText={(t) => handleChange('school_name', t)}
                            icon={<Building size={18} color="#94A3B8" />}
                        />
                        <AppInput
                            label="School Code (Unique)"
                            placeholder="e.g. SF001"
                            value={form.school_code}
                            onChangeText={(t) => handleChange('school_code', t)}
                            icon={<Building size={18} color="#94A3B8" />}
                        />
                        <AppInput
                            label="Official Email"
                            placeholder="contact@school.com"
                            value={form.email}
                            onChangeText={(t) => handleChange('email', t)}
                            icon={<Mail size={18} color="#94A3B8" />}
                        />
                        <AppInput
                            label="Phone Number"
                            placeholder="+1 234 567 890"
                            value={form.phone}
                            onChangeText={(t) => handleChange('phone', t)}
                            icon={<Phone size={18} color="#94A3B8" />}
                        />
                        <AppInput
                            label="Address"
                            placeholder="Full Address"
                            value={form.address}
                            onChangeText={(t) => handleChange('address', t)}
                            icon={<MapPin size={18} color="#94A3B8" />}
                            multiline
                        />
                    </AppCard>

                    <Text className="text-lg font-bold text-slate-800 mb-4 mt-2">Admin Account</Text>
                    <AppCard>
                        <AppInput
                            label="Admin Name"
                            placeholder="Principal Name"
                            value={form.admin_name}
                            onChangeText={(t) => handleChange('admin_name', t)}
                            icon={<User size={18} color="#94A3B8" />}
                        />
                        <AppInput
                            label="Admin Email"
                            placeholder="admin@school.com"
                            value={form.admin_email}
                            onChangeText={(t) => handleChange('admin_email', t)}
                            icon={<Mail size={18} color="#94A3B8" />}
                        />
                        <AppInput
                            label="Initial Password"
                            placeholder="Strong Password"
                            value={form.admin_password}
                            onChangeText={(t) => handleChange('admin_password', t)}
                            secureTextEntry
                            icon={<Lock size={18} color="#94A3B8" />}
                        />
                    </AppCard>

                    <AppButton title="Create School & Account" onPress={handleSubmit} loading={isLoading} className="mb-10" />
                </ScrollView>
            </SafeAreaView>
        </ScreenWrapper>
    );
};

export default CreateSchoolScreen;
