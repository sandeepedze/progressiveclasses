import React, { useState } from 'react';
import { View, Text, ScrollView, Alert } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import AppInput from '../../components/ui/AppInput';
import AppButton from '../../components/ui/AppButton';
import AppHeader from '../../components/layout/AppHeader';
import { Layers, DollarSign } from 'lucide-react-native';
import { useApiMutation } from '../../hooks/useApiMutation';
import { subscriptionService } from '../../services'; // Ensure this service exists or update import

const CreatePlanScreen = ({ navigation }) => {
    const [form, setForm] = useState({
        plan_name: '',
        price_monthly: '',
        price_yearly: '',
        max_users: '',
        max_students: ''
    });

    // Mock service if not yet created in subscriptionService
    const createPlanApi = subscriptionService?.createPlan || (async () => ({ success: true }));

    const { mutate, isLoading } = useApiMutation(createPlanApi, {
        successMessage: 'Plan Created!',
        onSuccess: () => navigation.goBack()
    });

    const handleSubmit = () => {
        if (!form.plan_name) return Alert.alert('Error', 'Plan name required');
        mutate(form);
    };

    return (
        <SafeAreaView className="flex-1 bg-white">
            <AppHeader title="Create Subscription Plan" />
            <ScrollView className="p-5">
                <AppInput
                    label="Plan Name"
                    placeholder="e.g. Gold Plan"
                    value={form.plan_name}
                    onChangeText={t => setForm({ ...form, plan_name: t })}
                    icon={<Layers size={20} color="gray" />}
                />
                <View className="flex-row justify-between">
                    <View className="w-[48%]">
                        <AppInput
                            label="Monthly Price"
                            placeholder="0.00"
                            keyboardType="numeric"
                            value={form.price_monthly}
                            onChangeText={t => setForm({ ...form, price_monthly: t })}
                            icon={<DollarSign size={16} color="gray" />}
                        />
                    </View>
                    <View className="w-[48%]">
                        <AppInput
                            label="Yearly Price"
                            placeholder="0.00"
                            keyboardType="numeric"
                            value={form.price_yearly}
                            onChangeText={t => setForm({ ...form, price_yearly: t })}
                            icon={<DollarSign size={16} color="gray" />}
                        />
                    </View>
                </View>

                {/* More fields... */}

                <AppButton title="Create Plan" onPress={handleSubmit} loading={isLoading} />
            </ScrollView>
        </SafeAreaView>
    );
};

export default CreatePlanScreen;
