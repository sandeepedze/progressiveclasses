import React, { useState } from 'react';
import { View, Text, Image, KeyboardAvoidingView, Platform, ScrollView } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useDispatch, useSelector } from 'react-redux';
import { loginUser } from '../../features/auth/authSlice';
import AppInput from '../../components/ui/AppInput';
import AppButton from '../../components/ui/AppButton';
import { Mail, Lock } from 'lucide-react-native';

const LoginScreen = ({ navigation }) => {
    const dispatch = useDispatch();
    const { isLoading, error } = useSelector(state => state.auth);
    const [credentials, setCredentials] = useState({ email: '', password: '' });

    const handleLogin = async () => {
        dispatch(loginUser(credentials));
    };

    return (
        <SafeAreaView className="flex-1 bg-white">
            <KeyboardAvoidingView
                behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
                className="flex-1"
            >
                <ScrollView contentContainerStyle={{ flexGrow: 1, justifyContent: 'center', padding: 24 }}>
                    <View className="items-center mb-10">
                        {/* Placeholder for Logo */}
                        <View className="h-20 w-20 bg-indigo-600 rounded-2xl mb-4 items-center justify-center rotate-3">
                            <Text className="text-white font-bold text-3xl">S</Text>
                        </View>
                        <Text className="text-3xl font-bold text-slate-900">Welcome Back!</Text>
                        <Text className="text-slate-500 text-center mt-2">Sign in to manage your school or classes</Text>
                    </View>

                    <AppInput
                        label="Email Address"
                        placeholder="you@school.edu"
                        value={credentials.email}
                        onChangeText={(t) => setCredentials({ ...credentials, email: t })}
                        icon={<Mail size={20} color="#94A3B8" />}
                    />

                    <AppInput
                        label="Password"
                        placeholder="••••••••"
                        value={credentials.password}
                        onChangeText={(t) => setCredentials({ ...credentials, password: t })}
                        secureTextEntry
                        passwordToggle
                        icon={<Lock size={20} color="#94A3B8" />}
                    />

                    {error && <Text className="text-red-500 text-center mb-4">{error}</Text>}

                    <View className="mt-4">
                        <AppButton
                            title="Sign In"
                            onPress={handleLogin}
                            loading={isLoading}
                        />
                        <AppButton
                            title="Forgot Password?"
                            variant="ghost"
                            onPress={() => { }}
                            className="mt-2"
                        />
                    </View>

                    {/* Dev Helper - remove in prod */}
                    <View className="mt-10 p-4 bg-slate-50 rounded-lg">
                        <Text className="text-xs text-slate-400 font-bold mb-2">DEV SHORTCUTS</Text>
                        <Text className="text-xs text-blue-500" onPress={() => setCredentials({ email: 'super@admin.com', password: '123' })}>Super Admin: super@admin.com</Text>
                        <Text className="text-xs text-blue-500 mt-1" onPress={() => setCredentials({ email: 'school@admin.com', password: '123' })}>School Admin: school@admin.com</Text>
                    </View>

                </ScrollView>
            </KeyboardAvoidingView>
        </SafeAreaView>
    );
};

export default LoginScreen;
