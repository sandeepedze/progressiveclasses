import React from 'react';
import { View, Text, TouchableOpacity, Dimensions, Image } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Sparkles, ArrowRight } from 'lucide-react-native';

const { width } = Dimensions.get('window');

const WelcomeScreen = ({ navigation }) => {
    return (
        <View className="flex-1">
            <LinearGradient
                colors={['#1E1B3A', '#4F46E5']}
                className="flex-1"
                start={{ x: 0, y: 0 }}
                end={{ x: 1, y: 1 }}
            >
                <SafeAreaView className="flex-1 items-center justify-center relative">
                    {/* Decorative Shapes (Simulated with Views for performance) */}
                    <View
                        className="absolute top-20 left-[-50] w-64 h-64 rounded-full opacity-20"
                        style={{ backgroundColor: '#CFFFE5', transform: [{ scale: 1.5 }] }}
                    />
                    <View
                        className="absolute bottom-40 right-[-30] w-72 h-72 rounded-full opacity-20"
                        style={{ backgroundColor: '#DAD6F5' }}
                    />
                    <View
                        className="absolute top-1/3 right-10 w-20 h-20 rounded-full opacity-30"
                        style={{ backgroundColor: '#FFF7C0', blurRadius: 20 }}
                    />

                    {/* Starburst/Decor elements */}
                    <Sparkles size={40} color="#FFF7C0" style={{ position: 'absolute', top: '25%', right: '20%', opacity: 0.6 }} />
                    <Sparkles size={24} color="#FFF7C0" style={{ position: 'absolute', bottom: '35%', left: '15%', opacity: 0.4 }} />

                    {/* Content */}
                    <View className="items-center px-8 z-10 w-full">
                        <View className="mb-10 p-6 bg-white/10 rounded-3xl border border-white/20 shadow-xl">
                            <Sparkles size={64} color="#FFF7C0" />
                        </View>

                        <Text className="text-4xl font-bold text-white text-center mb-4 tracking-wide font-sans shadow-black shadow-sm">
                            Welcome!
                        </Text>

                        <Text className="text-lg text-indigo-100 text-center mb-16 font-medium leading-7">
                            Become the best in your industry!{'\n'}
                            Manage your school seamlessly with our{'\n'}all-in-one platform.
                        </Text>

                        <TouchableOpacity
                            onPress={() => navigation.navigate('Login')}
                            className="w-full bg-white rounded-2xl py-4 flex-row justify-center items-center shadow-lg active:scale-95 transition-all"
                            style={{ elevation: 5 }}
                        >
                            <Text className="text-[#1E1B3A] font-bold text-lg mr-2">Get Started</Text>
                            <ArrowRight size={20} color="#1E1B3A" />
                        </TouchableOpacity>
                    </View>
                </SafeAreaView>
            </LinearGradient>
        </View>
    );
};

export default WelcomeScreen;
