import React, { useState } from 'react';
import { View, TextInput, TouchableOpacity } from 'react-native';
import { Eye, EyeOff } from 'lucide-react-native';

const NovaInput = ({
    icon: Icon,
    placeholder,
    value,
    onChangeText,
    secureTextEntry,
    keyboardType = 'default',
    className
}) => {
    const [isPasswordVisible, setIsPasswordVisible] = useState(false);

    const isSecure = secureTextEntry && !isPasswordVisible;

    return (
        <View className={`flex-row items-center bg-gray-100 rounded-2xl px-4 h-14 mb-4 ${className} border border-transparent focus:border-gray-300`}>
            {Icon && (
                <View className="mr-3">
                    <Icon size={20} color="#9CA3AF" />
                </View>
            )}

            <TextInput
                className="flex-1 text-gray-800 text-base font-medium h-full"
                placeholder={placeholder}
                placeholderTextColor="#9CA3AF"
                value={value}
                onChangeText={onChangeText}
                secureTextEntry={isSecure}
                keyboardType={keyboardType}
            />

            {secureTextEntry && (
                <TouchableOpacity onPress={() => setIsPasswordVisible(!isPasswordVisible)}>
                    {isPasswordVisible ? (
                        <EyeOff size={20} color="#9CA3AF" />
                    ) : (
                        <Eye size={20} color="#9CA3AF" />
                    )}
                </TouchableOpacity>
            )}
        </View>
    );
};

export default NovaInput;
