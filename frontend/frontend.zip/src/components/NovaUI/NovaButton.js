import React from 'react';
import { TouchableOpacity, Text, View } from 'react-native';
import { CircleCheck } from 'lucide-react-native';

const NovaButton = ({ title, onPress, variant = 'primary', className, icon }) => {
    if (variant === 'secondary') {
        return (
            <TouchableOpacity
                activeOpacity={0.8}
                onPress={onPress}
                className={`bg-white rounded-full h-14 flex-row items-center px-2 shadow-sm ${className}`}
            >
                <View className="bg-black rounded-full w-10 h-10 items-center justify-center mr-3">
                    {icon || <CircleCheck size={20} color="white" />}
                </View>
                <Text className="text-black font-bold text-lg flex-1 text-center pr-12">
                    {title}
                </Text>
            </TouchableOpacity>
        );
    }

    return (
        <TouchableOpacity
            activeOpacity={0.8}
            onPress={onPress}
            className={`bg-black rounded-full h-14 items-center justify-center shadow-md ${className}`}
        >
            <Text className="text-white font-bold text-lg">
                {title}
            </Text>
        </TouchableOpacity>
    );
};

export default NovaButton;
