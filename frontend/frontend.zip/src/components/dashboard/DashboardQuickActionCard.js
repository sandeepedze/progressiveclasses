import React from 'react';
import { TouchableOpacity, Text, View } from 'react-native';
import { ChevronRight } from 'lucide-react-native';

const DashboardQuickActionCard = ({ title, icon, color, onPress }) => {
    return (
        <TouchableOpacity
            onPress={onPress}
            className="flex-row items-center bg-white p-4 rounded-2xl mb-3 shadow-sm border border-slate-100 active:bg-slate-50"
        >
            <View className="w-12 h-12 rounded-full items-center justify-center mr-4" style={{ backgroundColor: `${color}15` }}>
                {icon}
            </View>
            <View className="flex-1">
                <Text className="text-base font-bold text-slate-800">{title}</Text>
            </View>
            <ChevronRight size={20} color="#CBD5E1" />
        </TouchableOpacity>
    );
};

export default DashboardQuickActionCard;
