import React from 'react';
import { View, Text } from 'react-native';
import AppCard from '../ui/AppCard';

const DashboardStatCard = ({ title, value, icon, color, subtext }) => {
    return (
        <View className="w-40 mr-3">
            <AppCard className="p-4 h-full justify-between">
                <View className="flex-row justify-between items-start mb-2">
                    <View className="p-2 rounded-xl" style={{ backgroundColor: `${color}15` }}>
                        {icon}
                    </View>
                    <Text className="text-2xl font-bold text-slate-800">{value}</Text>
                </View>
                <View>
                    <Text className="text-slate-500 text-sm font-medium mb-1">{title}</Text>
                    {subtext && <Text className="text-xs text-green-600 font-medium">{subtext}</Text>}
                </View>
            </AppCard>
        </View>
    );
};

export default DashboardStatCard;
