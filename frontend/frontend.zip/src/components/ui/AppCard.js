import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { BlurView } from 'expo-blur';

const AppCard = ({
    children,
    gradient = false,
    glass = false,
    className = "",
    style
}) => {

    const containerClasses = `rounded-3xl p-5 mb-4 shadow-sm ${className}`;

    if (gradient) {
        return (
            <LinearGradient
                colors={['#ffffff', '#f8fafc']}
                className={`border border-indigo-50 ${containerClasses}`}
                style={style}
            >
                {children}
            </LinearGradient>
        );
    }

    if (glass) {
        return (
            <View style={[styles.glassContainer, style]} className={`overflow-hidden rounded-3xl mb-4 ${className}`}>
                <BlurView intensity={80} tint="light" style={StyleSheet.absoluteFill} />
                <View className="p-5 bg-white/60">
                    {children}
                </View>
            </View>
        );
    }

    return (
        <View className={`bg-white border border-slate-100 ${containerClasses}`} style={style}>
            {children}
        </View>
    );
};

const styles = StyleSheet.create({
    glassContainer: {

    }
})

export default AppCard;
