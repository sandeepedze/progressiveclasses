import React from 'react';
import { TouchableOpacity, Text, View, ActivityIndicator } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { colors, layout, gradients } from '../../theme/colors';

const AppButton = ({
    title,
    onPress,
    variant = 'primary',
    loading = false,
    disabled = false,
    icon = null,
    className = ""
}) => {

    const baseStyle = "flex-row items-center justify-center py-3 px-6 rounded-2xl shadow-sm";
    const textBaseStyle = "font-bold text-center text-base";

    if (variant === 'primary') {
        return (
            <TouchableOpacity
                onPress={onPress}
                disabled={disabled || loading}
                className={`w-full my-2 ${disabled ? 'opacity-50' : ''} ${className}`}
            >
                <LinearGradient
                    colors={gradients.primary}
                    start={{ x: 0, y: 0 }}
                    end={{ x: 1, y: 0 }}
                    style={{ paddingVertical: 14, paddingHorizontal: 20, borderRadius: 16, flexDirection: 'row', justifyContent: 'center', alignItems: 'center' }}
                >
                    {loading ? (
                        <ActivityIndicator color="#fff" size="small" />
                    ) : (
                        <>
                            {icon && <View className="mr-2">{icon}</View>}
                            <Text className="text-white font-bold text-lg tracking-wide">{title}</Text>
                        </>
                    )}
                </LinearGradient>
            </TouchableOpacity>
        );
    }

    // Outline variant
    if (variant === 'outline') {
        return (
            <TouchableOpacity
                onPress={onPress}
                disabled={disabled || loading}
                className={`w-full my-2 border-2 border-indigo-500 rounded-2xl py-3 flex-row justify-center items-center ${disabled ? 'opacity-50' : ''} ${className}`}
            >
                {loading ? <ActivityIndicator color={colors.primary.DEFAULT} size="small" /> : (
                    <>
                        {icon && <View className="mr-2">{icon}</View>}
                        <Text className="text-indigo-600 font-bold text-lg">{title}</Text>
                    </>
                )}
            </TouchableOpacity>
        );
    }

    // Ghost variant
    if (variant === 'ghost') {
        return (
            <TouchableOpacity
                onPress={onPress}
                disabled={disabled || loading}
                className={`my-1 py-2 ${disabled ? 'opacity-50' : ''} ${className}`}
            >
                <Text className="text-slate-500 text-center font-medium">{title}</Text>
            </TouchableOpacity>
        );
    }

    return null;
};

export default AppButton;
