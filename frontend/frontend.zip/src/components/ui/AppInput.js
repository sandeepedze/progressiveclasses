import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity } from 'react-native';
import { colors } from '../../theme/colors';
import { Eye, EyeOff } from 'lucide-react-native';

const AppInput = ({
    label,
    value,
    onChangeText,
    placeholder,
    secureTextEntry,
    error,
    icon,
    keyboardType = 'default',
    multiline = false,
    passwordToggle = false
}) => {
    const [visible, setVisible] = useState(false);
    const isSecure = passwordToggle ? (secureTextEntry && !visible) : secureTextEntry;

    return (
        <View className="mb-4 w-full">
            {label && <Text className="text-slate-600 font-medium mb-1.5 ml-1">{label}</Text>}

            <View className={`flex-row items-center bg-slate-50 border ${error ? 'border-red-500' : 'border-slate-200'} rounded-2xl px-4 py-3.5 focus:border-indigo-500`}>
                {icon && <View className="mr-3 opacity-70">{icon}</View>}

                <TextInput
                    className="flex-1 text-slate-800 text-base"
                    value={value}
                    onChangeText={onChangeText}
                    placeholder={placeholder}
                    secureTextEntry={isSecure}
                    placeholderTextColor="#94A3B8"
                    keyboardType={keyboardType}
                    multiline={multiline}
                />
                {passwordToggle && (
                    <TouchableOpacity onPress={() => setVisible(!visible)} className="ml-2">
                        {visible ? <EyeOff size={20} color="#94A3B8" /> : <Eye size={20} color="#94A3B8" />}
                    </TouchableOpacity>
                )}
            </View>

            {error && <Text className="text-red-500 text-xs mt-1 ml-1">{error}</Text>}
        </View>
    );
};

export default AppInput;
