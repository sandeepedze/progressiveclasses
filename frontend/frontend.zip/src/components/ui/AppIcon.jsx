import React from 'react';
import { Icon as LucideIcon } from 'lucide-react-native';

const AppIcon = ({ iconNode, component: Component, size = 20, color = '#1F2937', strokeWidth = 2 }) => {
    if (iconNode) {
        return <LucideIcon iconNode={iconNode} size={size} color={color} strokeWidth={strokeWidth} />;
    }
    if (Component) {
        return <Component size={size} color={color} strokeWidth={strokeWidth} />;
    }
    return null;
};

export default AppIcon;
