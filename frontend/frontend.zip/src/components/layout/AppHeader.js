import React from 'react';
import { View, Text, TouchableOpacity } from 'react-native';
import { ArrowLeft, Bell } from 'lucide-react-native';
import { colors } from '../../theme/colors';
import { useNavigation } from '@react-navigation/native';

const AppHeader = ({ title, showBack = true, showNotification = true }) => {
    const navigation = useNavigation();

    return (
        <View className="flex-row items-center justify-between px-5 py-4 bg-white border-b border-slate-100">
            <View className="flex-row items-center">
                {showBack && (
                    <TouchableOpacity onPress={() => navigation.goBack()} className="mr-3 p-1 rounded-full bg-slate-50">
                        <ArrowLeft size={20} color={colors.text.primaryLight} />
                    </TouchableOpacity>
                )}
                <Text className="text-xl font-bold text-slate-800">{title}</Text>
            </View>

            {showNotification && (
                <TouchableOpacity className="relative p-2 rounded-full bg-slate-50">
                    <Bell size={20} color={colors.text.secondaryLight} />
                    <View className="absolute top-2 right-2 w-2 h-2 bg-red-500 rounded-full border border-white" />
                </TouchableOpacity>
            )}
        </View>
    );
};

export default AppHeader;
