import React from 'react';
import { View, Text, Image } from 'react-native';
import { User } from 'lucide-react-native';

const ProfileHeaderCard = ({ user }) => {
    return (
        <View className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100 items-center mb-6">
            <View className="h-24 w-24 rounded-full bg-slate-100 items-center justify-center mb-4 border-4 border-white shadow-sm">
                {user?.profile_image ? (
                    <Image source={{ uri: user.profile_image }} className="h-full w-full rounded-full" />
                ) : (
                    <User size={40} color="#64748B" />
                )}
            </View>
            <Text className="text-xl font-bold text-slate-900">{user?.name || 'User'}</Text>
            <Text className="text-slate-500 mb-2">{user?.email}</Text>
            <View className="bg-blue-50 px-3 py-1 rounded-full">
                <Text className="text-blue-600 text-xs font-bold uppercase tracking-wider">
                    {(user?.role_code || user?.role || 'guest')?.toString().replace('_', ' ')}
                </Text>
            </View>
        </View>
    );
};

export default ProfileHeaderCard;
