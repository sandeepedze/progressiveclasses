import axios from 'axios';
import * as SecureStore from 'expo-secure-store';
import { API_CONFIG, API_ROUTES } from '../constants/apiRoutes';
import { logger } from '../utils/logger';

// 1. Create Axios Instance
const apiClient = axios.create({
    baseURL: API_CONFIG.BASE_URL,
    timeout: API_CONFIG.TIMEOUT,
    headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
    },
});

export const setupAxiosInterceptors = (store) => {
    // 2. Request Interceptor
    apiClient.interceptors.request.use(
        async (config) => {
            const token = await SecureStore.getItemAsync('userToken');
            if (token) {
                config.headers.Authorization = `Bearer ${token}`;
            }

            logger.debug(`API Request: ${config.method?.toUpperCase()} ${config.url}`, config.data);
            return config;
        },
        (error) => {
            logger.error('API Request Error', error);
            return Promise.reject(error);
        }
    );

    // 3. Response Interceptor
    apiClient.interceptors.response.use(
        (response) => {
            logger.debug(`API Response: ${response.status} ${response.config.url}`, response.data);

            const { success, message } = response.data;

            if (success === false) {
                const customError = new Error(message || 'Operation failed at backend');
                customError.isBusinessError = true;
                customError.response = response;
                return Promise.reject(customError);
            }

            return response.data;
        },
        async (error) => {
            const originalRequest = error.config;

            console.log("AXIOS ERROR FULL:", error);
            console.log("AXIOS ERROR MESSAGE:", error?.message);
            console.log("AXIOS ERROR CODE:", error?.code);
            console.log("AXIOS RESPONSE STATUS:", error?.response?.status);
            console.log("AXIOS RESPONSE DATA:", error?.response?.data);

            // Handle Network Errors
            if (!error.response) {
                logger.error('Network Error - No Response', error);
                return Promise.reject(new Error('Network error. Please check your internet connection.'));
            }

            if (error.response.status === 401 && !originalRequest._retry) {
                originalRequest._retry = true;
                try {
                    logger.warn('Token expired or invalid, logging out...');

                    // Safe Logout Logic using Store
                    await SecureStore.deleteItemAsync('userToken');
                    await SecureStore.deleteItemAsync('userData');

                    if (store) {
                        // Using type string to avoid importing from slice
                        store.dispatch({ type: 'auth/logout/fulfilled' });
                    }

                    return Promise.reject(new Error('Session expired. Please login again.'));
                } catch (refreshError) {
                    return Promise.reject(refreshError);
                }
            }

            const serverMessage = error.response?.data?.message || 'Something went wrong';
            logger.error(`API Failure: ${serverMessage}`, error);

            return Promise.reject(new Error(serverMessage));
        }
    );
};

export default apiClient;
