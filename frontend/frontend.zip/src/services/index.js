import apiClient from './apiClient';
import { API_ROUTES } from '../constants/apiRoutes';

export const authService = {
    login: async (credentials) => {
        // apiClient returns response.data automatically due to interceptor
        return await apiClient.post(API_ROUTES.AUTH.LOGIN, credentials);
    },
    logout: async () => {
        // Best effort logout
        try {
            await apiClient.post(API_ROUTES.AUTH.LOGOUT);
        } catch (e) {
            // Ignore
        }
    }
};

export const schoolService = {
    createSchool: async (schoolData) => {
        return await apiClient.post(API_ROUTES.SUPER_ADMIN.CREATE_SCHOOL, schoolData);
    }
};

export const subscriptionService = {
    createPlan: async (payload) => {
        console.log('DEBUG: Creating plan with payload:', payload, 'URL:', API_ROUTES.SUPER_ADMIN.CREATE_PLAN);
        const res = await apiClient.post(API_ROUTES.SUPER_ADMIN.CREATE_PLAN, payload);
        console.log('DEBUG: Create plan response:', res);
        return res;
    }
};

export const userService = {
    uploadAvatar: async (formData) => {
        console.log('DEBUG: Uploading avatar to:', API_ROUTES.USER.UPLOAD_AVATAR);
        return await apiClient.post(API_ROUTES.USER.UPLOAD_AVATAR, formData);
    }
};
