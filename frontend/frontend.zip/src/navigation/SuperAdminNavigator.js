import React from 'react';
import { createStackNavigator } from '@react-navigation/stack';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { School, LayoutDashboard, CreditCard, Box, Settings } from 'lucide-react-native';
import AppIcon from '../components/ui/AppIcon';
import SuperAdminDashboard from '../screens/superadmin/DashboardScreen';
import CreateSchoolScreen from '../screens/superadmin/CreateSchoolScreen';
import CreatePlanScreen from '../screens/superadmin/CreatePlanScreen';
import SettingsScreen from '../screens/common/SettingsScreen';
import ProfileScreen from '../screens/common/ProfileScreen';
import { colors } from '../theme/colors';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

const Stack = createStackNavigator();
const Tab = createBottomTabNavigator();

const SuperAdminTabs = () => {
    const insets = useSafeAreaInsets();
    return (
        <Tab.Navigator
            screenOptions={{
                headerShown: false,
                tabBarStyle: {
                    borderTopWidth: 0,
                    elevation: 10,
                    shadowColor: '#000',
                    shadowOffset: { width: 0, height: 4 },
                    shadowOpacity: 0.1,
                    height: 65 + (insets.bottom || 0),
                    paddingBottom: Math.max(12, (insets.bottom || 0) + 8),
                    paddingTop: 10,
                },
                tabBarActiveTintColor: colors.primary.DEFAULT,
                tabBarInactiveTintColor: '#94A3B8',
                tabBarLabelStyle: {
                    fontSize: 12,
                    fontWeight: '600',
                }
            }}
        >
            <Tab.Screen
                name="Dashboard"
                component={SuperAdminDashboard}
                options={{
                    tabBarIcon: ({ color, size }) => <AppIcon component={LayoutDashboard} size={size} color={color} />
                }}
            />
            <Tab.Screen
                name="Schools"
                component={SuperAdminDashboard} // Placeholder
                options={{
                    tabBarIcon: ({ color, size }) => <AppIcon component={School} size={size} color={color} />
                }}
            />
            <Tab.Screen
                name="Plans"
                component={SuperAdminDashboard} // Placeholder
                options={{
                    tabBarIcon: ({ color, size }) => <AppIcon component={CreditCard} size={size} color={color} />
                }}
            />
            <Tab.Screen
                name="Settings"
                component={SettingsScreen}
                options={{
                    tabBarIcon: ({ color, size }) => <AppIcon component={Settings} size={size} color={color} />
                }}
            />
        </Tab.Navigator>
    );
};

const SuperAdminNavigator = () => {
    return (
        <Stack.Navigator screenOptions={{ headerShown: false, presentation: 'card' }}>
            <Stack.Screen name="SuperAdminTabs" component={SuperAdminTabs} />
            <Stack.Screen name="CreateSchool" component={CreateSchoolScreen} />
            <Stack.Screen name="CreatePlan" component={CreatePlanScreen} />
            <Stack.Screen name="Profile" component={ProfileScreen} />
            {/* Add CreatePlan, etc. */}
        </Stack.Navigator>
    );
};

export default SuperAdminNavigator;
