import React, { useEffect } from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import { useSelector, useDispatch } from 'react-redux';
import { ActivityIndicator, View } from 'react-native';
import LoginScreen from '../screens/auth/LoginScreen';
import WelcomeScreen from '../screens/auth/WelcomeScreen';
import SuperAdminNavigator from './SuperAdminNavigator';
import { restoreToken } from '../features/auth/authSlice';
import { colors } from '../theme/colors';

const Stack = createStackNavigator();

export default function AppNavigator() {
    const dispatch = useDispatch();
    const { isAuthenticated, isLoading, user } = useSelector(state => state.auth);

    useEffect(() => {
        dispatch(restoreToken());
    }, [dispatch]);

    if (isLoading) {
        return (
            <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
                <ActivityIndicator size="large" color={colors.primary.DEFAULT} />
            </View>
        );
    }

    return (
        <NavigationContainer>
            <Stack.Navigator screenOptions={{ headerShown: false }}>
                {isAuthenticated ? (
                    // Dynamic Route Switching based on Role (Super Admin logic)
                    (user?.role_code === 'SUPER_ADMIN' || user?.role === 'super_admin') ? (
                        <Stack.Screen name="SuperAdminRoot" component={SuperAdminNavigator} />
                    ) : (user?.role_code === 'SCHOOL_ADMIN' || user?.role === 'school_admin') ? (
                        <Stack.Screen name="SchoolAdminRoot" component={SuperAdminNavigator} />
                    ) : (
                        <Stack.Screen name="UserRoot" component={SuperAdminNavigator} />
                    )
                ) : (
                    <>
                        <Stack.Screen name="Welcome" component={WelcomeScreen} />
                        <Stack.Screen name="Login" component={LoginScreen} />
                    </>
                )}
            </Stack.Navigator>
        </NavigationContainer>
    );
}
