// PostCSS config disabled - NativeWind/Tailwind not compatible with Expo Metro bundler
module.exports = {
  plugins: {},
};
